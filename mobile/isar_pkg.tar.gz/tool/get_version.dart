import 'package:isar/isar.dart';

void main() {
  // ignore: avoid_print
  print(Isar.version);
}
