// ignore_for_file: public_member_api_docs

import 'package:isar/src/web/isar_web.dart';

List<String> isarSplitWords(String input) => unsupportedOnWeb();
