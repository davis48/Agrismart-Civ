// no id property defined

import 'package:isar/isar.dart';

@collection
class Test {
  late int notId;

  late String name;
}
