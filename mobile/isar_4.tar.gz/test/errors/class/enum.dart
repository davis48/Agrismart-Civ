// only classes

import 'package:isar/isar.dart';

// ignore: invalid_annotation_target
@collection
enum Test { a, b, c }
