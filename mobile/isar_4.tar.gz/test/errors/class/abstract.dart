// must not be abstract

import 'package:isar/isar.dart';

@collection
abstract class Model {
  late int id;
}
