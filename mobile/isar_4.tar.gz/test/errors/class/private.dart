// must be public

import 'package:isar/isar.dart';

@collection
// ignore: unused_element
class _Model {
  late int id;
}
