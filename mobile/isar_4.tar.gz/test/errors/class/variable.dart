// only classes

import 'package:isar/isar.dart';

// ignore: invalid_annotation_target
@collection
const t = 'hello';
