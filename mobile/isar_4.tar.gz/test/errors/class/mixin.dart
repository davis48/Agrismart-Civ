// only classes

import 'package:isar/isar.dart';

// ignore: invalid_annotation_target
@collection
mixin Test {}
